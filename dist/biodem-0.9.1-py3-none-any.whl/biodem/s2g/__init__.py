r"""
Transform genotype data into genome block representations.
"""
from biodem.s2g import model
from biodem.s2g import pipeline
