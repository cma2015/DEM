r"""
The DEM pipelines for training, predicting and feature ranking.
"""
from biodem.dem import model
from biodem.dem import pipeline
from biodem.dem import rank
