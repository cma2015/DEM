using PackageCompiler
using Pkg
Pkg.activate(".")
create_app(".", "DEMpre_compiled")

exit()
