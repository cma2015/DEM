"""
DEM in Python.

DEM python library.
"""

name = "biodem"
__version__ = "0.2.0"
__author__ = 'Yanlin Ren, Chenhua Wu'
__credits__ = 'Northwest A&F University'

from . import cli_dem
