from setuptools import setup

setup(
    name='biodem',
    packages=['biodem'],
)
